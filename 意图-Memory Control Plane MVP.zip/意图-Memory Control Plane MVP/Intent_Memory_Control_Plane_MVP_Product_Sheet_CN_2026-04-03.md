# Intent-Memory Control Plane MVP Product Sheet

## 产品定位

Intent-Memory Control Plane 是面向 **可控大模型 / 可信智能体 / 多模型平台** 的语义控制面。它把任务执行前后的关键控制点统一到一个可解释、可续接、可回放的运行层：

- **Intent contract**：把用户目标、约束、deliverable、success criteria 和禁止动作编译为活动合同
- **Memory registry**：把偏好、规则、事实、政策写入版本化记忆，并保留审批与差异链
- **Backend routing**：根据任务类型、能力标签和优先级选择真实模型后端
- **Transfer / handoff**：把跨任务、跨角色、跨代理续接所需的约束和记忆打包为 handoff packet
- **Alignment / drift**：对计划、输出和后续任务做对齐检查与目标偏航告警
- **Multi-agent workflow**：统一 planner / reasoner / auditor 的协同执行与留痕

## 核心买方

- 多模型平台 / Agent 平台团队
- AI 中台 / 知识平台 / 数据治理平台
- 智慧城市 / 行业数字化平台
- 高责任场景的模型治理与交付团队

## MVP 模块清单

| Module | Name | Summary |
|---|---|---|
| CP-01 | Intent Contract Compiler | 提取目标、约束、成功标准、偏好与禁止动作。 |
| CP-02 | Session Resume & Transfer | 保存跨任务 handoff，复用前一任务的约束和背景。 |
| CP-03 | Versioned Memory Registry | 管理长期偏好、规则、政策、事实和版本回写。 |
| CP-04 | Semantic Graph Query | 用图谱方式查询 identity / purpose / value / evidence 路径。 |
| CP-05 | Backend Router | 根据任务类型和能力标签路由模型后端。 |
| CP-06 | Multi-Agent Planner | 编排 planner / reasoner / auditor 的分工与协同。 |
| CP-07 | Goal Drift Detector | 发现与当前意图合同不一致的偏航，并给出纠偏建议。 |
| CP-08 | Human-AI Alignment Check | 比较用户目标与系统行动计划的一致性。 |


## MVP 演示亮点

1. **Compile intent**：输入复杂任务后，系统会生成 objective、constraints、deliverables、success criteria、clarification questions 和 candidate agents。
2. **Route backend**：系统根据 required capabilities 和 backend inventory 给出可解释的后端选路结果。
3. **Write memory**：对长期偏好、规则、事实、政策的写入会形成版本链和审批留痕。
4. **Detect drift**：当后续任务试图移除审计、切换高风险域或改变 deliverable 时，系统给出 drift / conflict 告警。
5. **Create handoff packet**：为下一任务或下一角色输出 carry-forward constraints、memory keys、alignment snapshot 和 route snapshot。
6. **Run multi-agent**：planner / reasoner / auditor 协作，并返回 alignment score 和 consensus summary。
