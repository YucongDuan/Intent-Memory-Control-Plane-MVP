# Intent-Memory Control Plane MVP Runbook

## 1. 安装

```bash
cd Intent_Memory_Control_Plane_MVP_Project
python -m venv .venv
source .venv/bin/activate
pip install -e .
cp .env.example .env
```

## 2. 启动 API

```bash
python -m dikwp_products.api
```

访问：

- `http://127.0.0.1:8765/`
- `http://127.0.0.1:8765/docs`

## 3. 核心试点路径

### 路径 A：Compile → Plan → Run
1. 在 UI 或 API 里调用 `/api/control-plane/compile-intent`
2. 调用 `/api/control-plane/plan` 查看 stage plan 和 backend route
3. 调用 `/api/control-plane/run` 执行任务并返回 alignment score

### 路径 B：Memory Registry
1. 调用 `/api/control-plane/memory/write`
2. 如果产生审批单，则调用 `/api/control-plane/memory/approve`
3. 调用 `/api/control-plane/memory/list` 查看 memory store 和 versions

### 路径 C：Transfer / Handoff
1. 调用 `/api/control-plane/drift` 检查后续任务是否偏航
2. 调用 `/api/control-plane/handoff` 生成 carry-forward packet
3. 调用 `/api/control-plane/state` 导出当前 control-plane 概览

## 4. 演示建议

- 先用“多模型治理 → 智慧城市标准映射”的任务链演示 compile / drift / handoff
- 再用“长期偏好写入 + 版本化查询”演示 memory registry
- 最后用 planner / reasoner / auditor 演示 multi-agent 协作与 alignment check

## 5. MVP 边界

当前版本适合对外试点，不等同于生产系统。上线前仍需补：

- IAM / SSO
- 多租户隔离
- 生产日志 / SIEM
- 组织审批流集成
- 更细粒度 retention / deletion policy
